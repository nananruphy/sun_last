package com.example.akosombotour;

public class Akosombo {
    /**
     * Default translation for the word
     */
    private String mAkosombo_items;


    public Akosombo(String akosombo_items) {
        mAkosombo_items = akosombo_items;
    }


    public String getakosombo_items() {
        return mAkosombo_items;
    }


}
